rootProject.name = "PermissionsPlayground"
include(":app")
